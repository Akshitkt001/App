package com.example.myapplication.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Constants.Constants;
import com.example.myapplication.Model.Note;
import com.example.myapplication.NoteAdapter;
import com.example.myapplication.R;
import com.example.myapplication.database_helper.sqlite.DatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class NotesFragment extends Fragment implements NoteAdapter.NoteActionListener {
    private RecyclerView recyclerView;
    private FloatingActionButton addNoteButton;
    private FloatingActionButton showDeletedButton;
    private NoteAdapter noteAdapter;
    private ArrayList<Note> noteList; // Change from List<Note> to ArrayList<Note>
    private DatabaseHelper sqliteDataHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.notes_fragment, container, false);

        // Initialize views
        addNoteButton = rootView.findViewById(R.id.add_note_button);
        showDeletedButton = rootView.findViewById(R.id.show_deleted_button);
        recyclerView = rootView.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize database helper
        sqliteDataHelper = new DatabaseHelper(getContext());

        // Get all notes from database
        noteList = new ArrayList<>(); // Initialize noteList as ArrayList
        noteList.addAll(sqliteDataHelper.getNotes()); // Add notes from database to ArrayList

        // Set up RecyclerView adapter with action listener
        noteAdapter = new NoteAdapter(noteList, getContext(), this);
        recyclerView.setAdapter(noteAdapter);

        // Add note button click listener
        addNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long id = sqliteDataHelper.addNote();
                Note newNote = new Note();
                newNote.setId(id);
                newNote.setText("New Note");
                newNote.setDate("Date"); // Replace with actual date logic if needed
                noteList.add(newNote);
                noteAdapter.notifyDataSetChanged();
                itemClicked(newNote);
            }
        });

        // Show deleted button click listener
        showDeletedButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDeletedNotes();
            }
        });

        return rootView;
    }

    // Method to show deleted notes fragment
    private void showDeletedNotes() {
        ShowDeletedFilesFragment showDeletedFilesFragment = new ShowDeletedFilesFragment();
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, showDeletedFilesFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // Open Edit Note Fragment and pass note to fragment
    public void itemClicked(Note note) {
        EditNoteFragment editNoteFragment = new EditNoteFragment();
        Bundle args = new Bundle();
        args.putSerializable(Constants.ADD_NOTE_FRAGMENT, note);
        editNoteFragment.setArguments(args);

        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, editNoteFragment, Constants.ADD_NOTE_FRAGMENT);
        transaction.addToBackStack(null);
        transaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        transaction.commit();
    }

    @Override
    public void onNoteDelete(int position) {
        Note deletedNote = noteList.remove(position);
        sqliteDataHelper.deleteNoteById(deletedNote.getId());
        noteAdapter.notifyItemRemoved(position);
        Toast.makeText(getContext(), "Note deleted: " + deletedNote.getId(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNoteClick(int position) {
        Note clickedNote = noteList.get(position);
        Toast.makeText(getContext(), "Clicked on note: " + clickedNote.getId(), Toast.LENGTH_SHORT).show();
        itemClicked(clickedNote);
    }
}
