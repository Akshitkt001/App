package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity; // Import AppCompatActivity
import android.os.Bundle; // Import Bundle for handling saved state
import android.view.Menu; // Import Menu for handling menus
import android.view.MenuItem; // Import MenuItem for handling menu items

import com.example.myapplication.Constants.Constants; // Import Constants class if needed
import com.example.myapplication.Fragments.LoginFragment; // Import LoginFragment
import com.example.myapplication.Fragments.NotesFragment; // Import NotesFragment
import com.example.myapplication.database_helper.sqlite.SharedPreferenceManager; // Import SharedPreferenceManager


public class MainActivity extends AppCompatActivity {

    private LoginFragment loginFragment;
    private NotesFragment notesFragment;
    private SharedPreferenceManager spm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spm = new SharedPreferenceManager(this);

        if (!spm.isLoggedIn()) {
            showLoginFragment();
        } else {
            showNotesFragment();
        }
    }

    private void showLoginFragment() {
        loginFragment = new LoginFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, loginFragment, Constants.LOGIN_FRAGMENT)
                .commit();
    }

    private void showNotesFragment() {
        notesFragment = new NotesFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragment_container, notesFragment, Constants.NOTES_FRAGMENT)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.logout) {
            spm.logoutUser();
            showLoginFragment();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}