package com.example.myapplication.Fragments;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;

import com.example.myapplication.Constants.Constants;
import com.example.myapplication.R;
import com.example.myapplication.database_helper.sqlite.SharedPreferenceManager;

public class LoginFragment extends Fragment {

    AutoCompleteTextView userEmail;
    EditText userPassword;
    Button signInBtn;
    SharedPreferenceManager spm;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.login_fragment, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();
        spm = new SharedPreferenceManager(getActivity());
        View rootView = getView();
        if (rootView != null) {
            userEmail = rootView.findViewById(R.id.email);
            userPassword = rootView.findViewById(R.id.password);
            signInBtn = rootView.findViewById(R.id.email_sign_in_button);
            // SignIn button click listener
            signInBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = userEmail.getText().toString().trim();
                    String pass = userPassword.getText().toString().trim();

                    // Check if null values are passed when trying to login
                    if (!email.isEmpty() && !pass.isEmpty()) {
                        //  If values are not null create login session and save to shared preference
                        spm.createLoginSession(email);
                        //  open Notes Fragment after login
                        openNotes();
                    }
                }
            });
        }
    }

    public void openNotes() {
        NotesFragment noteFragment = new NotesFragment();
        FragmentTransaction transaction = getParentFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, noteFragment, Constants.NOTES_FRAGMENT);
        transaction.commit();
    }
}
