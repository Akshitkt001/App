package com.example.myapplication.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Note;
import com.example.myapplication.R;
import com.example.myapplication.DeletedNotesAdapter;
import com.example.myapplication.database_helper.sqlite.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

public class ShowDeletedFilesFragment extends Fragment {

    private RecyclerView recyclerView;
    private List<Note> deletedNotesList;
    private DeletedNotesAdapter deletedNotesAdapter;
    private DatabaseHelper sqliteDataHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_show_deleted_files, container, false);

        recyclerView = rootView.findViewById(R.id.deleted_notes_recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Initialize database helper
        sqliteDataHelper = new DatabaseHelper(getContext());

        // Get deleted notes from database
        deletedNotesList = sqliteDataHelper.getDeletedNotes();

        // Set up RecyclerView adapter for deleted notes
        deletedNotesAdapter = new DeletedNotesAdapter(new ArrayList<>(deletedNotesList), getContext());
        recyclerView.setAdapter(deletedNotesAdapter);

        return rootView;
    }

    // Restore deleted note
    public void restoreNote(long id) {
        sqliteDataHelper.restoreNoteById(id);
        // After restoration, update the UI if necessary
        deletedNotesList.clear();
        deletedNotesList.addAll(sqliteDataHelper.getDeletedNotes());
        deletedNotesAdapter.notifyDataSetChanged(); // Notify adapter of dataset change
    }
}
