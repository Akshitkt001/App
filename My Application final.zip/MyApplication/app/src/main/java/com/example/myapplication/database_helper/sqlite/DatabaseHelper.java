package com.example.myapplication.database_helper.sqlite;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.myapplication.Constants.Constants;
import com.example.myapplication.Model.Note;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    public DatabaseHelper(Context context) {
        super(context, Constants.DATABASENAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            // Create the user table
            db.execSQL("CREATE TABLE " + Constants.USER_TABLE
                    + "(" + Constants.USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + Constants.USER_EMAIL + " TEXT, "
                    + Constants.USER_PASS + " TEXT )");

            // Create the notes table
            db.execSQL("CREATE TABLE " + Constants.NOTES_TABLE
                    + "(" + Constants.NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + Constants.NOTE_DATE + " TEXT, "
                    + Constants.NOTE + " TEXT )");

            // Create the deleted notes table
            db.execSQL("CREATE TABLE " + Constants.DELETED_NOTES_TABLE
                    + "(" + Constants.NOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + Constants.NOTE_DATE + " TEXT, "
                    + Constants.NOTE + " TEXT )");

        } catch (SQLException e) {
            Log.d("Database_CREATE", e.getMessage());
        }
    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Constants.USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + Constants.NOTES_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + Constants.DELETED_NOTES_TABLE);
        onCreate(db);
    }

    public int updateNote(String note, long id) {
        Log.d("updateNotePos :", String.valueOf(id));
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Constants.NOTE, note);
        cv.put(Constants.NOTE_DATE, setInitialDate());
        return db.update(Constants.NOTES_TABLE, cv, Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)});
    }

    public List<Note> getNotes() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<Note> noteList = new ArrayList<>();
        Cursor cur = null;
        try {
            cur = db.rawQuery("SELECT * FROM " + Constants.NOTES_TABLE, null);
            if (cur != null && cur.moveToFirst()) {
                // Log column indices
                int noteIndex = cur.getColumnIndex(Constants.NOTE);
                int idIndex = cur.getColumnIndex(Constants.NOTE_ID);
                int dateIndex = cur.getColumnIndex(Constants.NOTE_DATE);
                Log.d("ColumnIndices", "Note Index: " + noteIndex + ", ID Index: " + idIndex + ", Date Index: " + dateIndex);

                do {
                    Note note = new Note();
                    if (noteIndex != -1) {
                        note.setText(cur.getString(noteIndex));
                    } else {
                        Log.d("ColumnIndices", "Note Index is -1");
                    }
                    if (idIndex != -1) {
                        note.setId(cur.getLong(idIndex));
                    } else {
                        Log.d("ColumnIndices", "ID Index is -1");
                    }
                    if (dateIndex != -1) {
                        note.setDate(cur.getString(dateIndex));
                    } else {
                        Log.d("ColumnIndices", "Date Index is -1");
                    }
                    noteList.add(note);
                } while (cur.moveToNext());
            }
        } catch (Exception e) {
            Log.d("GET NOTES", e.getMessage());
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return noteList;
    }



    public List<Note> getDeletedNotes() {
        SQLiteDatabase db = this.getWritableDatabase();
        List<Note> deletedNoteList = new ArrayList<>();
        Cursor cur = null;
        try {
            cur = db.rawQuery("SELECT * FROM " + Constants.DELETED_NOTES_TABLE, null);
            if (cur != null && cur.moveToFirst()) {
                int noteIndex = cur.getColumnIndex(Constants.NOTE);
                int idIndex = cur.getColumnIndex(Constants.NOTE_ID);
                int dateIndex = cur.getColumnIndex(Constants.NOTE_DATE);
                do {
                    Note note = new Note();
                    if (noteIndex != -1) {
                        note.setText(cur.getString(noteIndex));
                    }
                    if (idIndex != -1) {
                        note.setId(cur.getLong(idIndex));
                    }
                    if (dateIndex != -1) {
                        note.setDate(cur.getString(dateIndex));
                    }
                    deletedNoteList.add(note);
                } while (cur.moveToNext());
            }
        } catch (Exception e) {
            Log.d("GET DELETED NOTES", e.getMessage());
        } finally {
            if (cur != null) {
                cur.close();
            }
        }
        return deletedNoteList;
    }

    public long addNote() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Constants.NOTE_DATE, setInitialDate());
        return db.insert(Constants.NOTES_TABLE, null, cv);
    }

    public long deleteNoteById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        // Before deleting, move the note to deleted notes table
        moveNoteToDeletedNotes(db, id);
        // Now delete from the main notes table
        return db.delete(Constants.NOTES_TABLE, Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)});
    }

    public long restoreNoteById(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(Constants.DELETED_NOTES_TABLE, null,
                    Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)},
                    null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                ContentValues cv = new ContentValues();
                cv.put(Constants.NOTE_DATE, cursor.getString(cursor.getColumnIndex(Constants.NOTE_DATE)));
                cv.put(Constants.NOTE, cursor.getString(cursor.getColumnIndex(Constants.NOTE)));
                long insertedId = db.insert(Constants.NOTES_TABLE, null, cv); // Restore to main notes table
                db.delete(Constants.DELETED_NOTES_TABLE, Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)}); // Delete from deleted notes table
                return insertedId;
            }
        } catch (Exception e) {
            Log.d("RESTORE NOTE", e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return -1; // Return -1 if restoration fails
    }

    public boolean noteExists(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(Constants.NOTES_TABLE, new String[]{Constants.NOTE_ID},
                    Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)},
                    null, null, null);
            return cursor != null && cursor.moveToFirst();
        } catch (Exception e) {
            Log.d("NOTE EXISTS", e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public boolean deletedNoteExists(long id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.query(Constants.DELETED_NOTES_TABLE, new String[]{Constants.NOTE_ID},
                    Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)},
                    null, null, null);
            return cursor != null && cursor.moveToFirst();
        } catch (Exception e) {
            Log.d("DELETED NOTE EXISTS", e.getMessage());
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public int countNotes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT COUNT(*) FROM " + Constants.NOTES_TABLE, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.d("COUNT NOTES", e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return 0;
    }

    public int countDeletedNotes() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("SELECT COUNT(*) FROM " + Constants.DELETED_NOTES_TABLE, null);
            if (cursor != null && cursor.moveToFirst()) {
                return cursor.getInt(0);
            }
        } catch (Exception e) {
            Log.d("COUNT DELETED NOTES", e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        return 0;
    }

    private void moveNoteToDeletedNotes(SQLiteDatabase db, long id) {
        Cursor cursor = null;
        try {
            cursor = db.query(Constants.NOTES_TABLE, null,
                    Constants.NOTE_ID + "=?", new String[]{String.valueOf(id)},
                    null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                ContentValues cv = new ContentValues();
                cv.put(Constants.NOTE_DATE, cursor.getString(cursor.getColumnIndex(Constants.NOTE_DATE)));
                cv.put(Constants.NOTE, cursor.getString(cursor.getColumnIndex(Constants.NOTE)));
                db.insert(Constants.DELETED_NOTES_TABLE, null, cv);
            }
        } catch (Exception e) {
            Log.d("MOVE TO DELETED NOTES", e.getMessage());
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    private String setInitialDate() {
        Calendar calendar = Calendar.getInstance();
        DateFormat df = new SimpleDateFormat("E hh:mm a");
        return df.format(calendar.getTime());
    }
}
