package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Note;
import com.example.myapplication.R;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.ViewHolder> {
    private ArrayList<Note> dataSet;
    private Context mContext;
    private NoteActionListener noteActionListener;

    public NoteAdapter(ArrayList<Note> data, Context context, NoteActionListener listener) {
        this.dataSet = data;
        this.mContext = context;
        this.noteActionListener = listener;
    }

    public interface NoteActionListener {
        void onNoteClick(int position);
        void onNoteDelete(int position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.note_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        Note note = dataSet.get(position);
        holder.noteText.setText(note.getText());
        holder.noteDate.setText(note.getDate());

        // Delete button click listener
        holder.noteDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Notify listener about delete action
                if (noteActionListener != null) {
                    noteActionListener.onNoteDelete(position);
                }
            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Notify listener about click action
                if (noteActionListener != null) {
                    noteActionListener.onNoteClick(position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return dataSet.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView noteText;
        TextView noteDate;
        ImageView noteDelete;

        public ViewHolder(View itemView) {
            super(itemView);
            noteText = itemView.findViewById(R.id.note_text);
            noteDate = itemView.findViewById(R.id.note_date);
            noteDelete = itemView.findViewById(R.id.note_delete);
        }
    }
}
