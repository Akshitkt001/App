package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.Model.Note;
import com.example.myapplication.R;

import java.util.ArrayList;

public class DeletedNotesAdapter extends RecyclerView.Adapter<DeletedNotesAdapter.ViewHolder> {

    private ArrayList<Note> deletedNotesList;
    private Context mContext;

    public DeletedNotesAdapter(ArrayList<Note> deletedNotesList, Context context) {
        this.deletedNotesList = deletedNotesList;
        this.mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.deleted_note_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Note note = deletedNotesList.get(position);
        holder.deletedNoteText.setText(note.getText());
        holder.deletedNoteDate.setText(note.getDate());
    }

    @Override
    public int getItemCount() {
        return deletedNotesList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView deletedNoteText;
        TextView deletedNoteDate;

        public ViewHolder(View itemView) {
            super(itemView);
            deletedNoteText = itemView.findViewById(R.id.deleted_note_text);
            deletedNoteDate = itemView.findViewById(R.id.deleted_note_date);
        }
    }
}
